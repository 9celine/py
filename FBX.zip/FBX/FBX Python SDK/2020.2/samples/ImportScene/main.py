# -*- coding: utf-8 -*-

import requests
import time
import json
import os
import ParseUtil
from werkzeug.utils import secure_filename
from flask_cors import *
from flask import Flask,render_template,request,Response,redirect,url_for,send_from_directory


#内网ip
app = Flask(__name__)
CORS(app, supports_credentials=True)


############################flask路由
#进入页面
@app.route('/')
def index2():
    return render_template('index.html')

@app.route('/json')
def test02():
    dirName = request.args.get('dirName')
    fileName = request.args.get('fileName')
    return send_from_directory(dirName, fileName)

# 上传文件
@app.route('/upload_file', methods=['POST', 'GET'])
def upload():
    if request.method == 'POST':
        f = request.files['file']
        basepath = os.path.dirname(__file__)  # 当前文件所在路径
        print(f.filename)
        #######################################
        # 毫秒级时间戳
        file_name = str(round(time.time() * 1000))
        dir = str(time.strftime('%y%m%d', time.localtime()))
        upload_path = os.path.join(basepath, 'uploads/'+dir)
        # 判断文件夹是否存在
        if not os.path.exists(upload_path):
            os.mkdir(upload_path)
        #######################################
        file_path = str(file_name)+str(f.filename)
        f.save(upload_path+"/"+file_path)
        print(upload_path)
        print(file_path)

    ParseUtil.parse(upload_path+"/"+file_path, upload_path+"/"+ file_path.split('.')[0] + ".json")
    redirectUrl = 'json?dirName='+ upload_path + "&fileName=" + file_path.split('.')[0] + ".json"

    return Response(json.dumps(redirectUrl), mimetype='application/json')

if __name__ == "__main__":
    """初始化,debug=True"""
    app.run(host='127.0.0.0', port=5000,debug=True)

