# -*- coding: utf-8 -*-
"""
Created on Tue Jan 25 15:49:02 2022

@author: FX
"""

import os
import json
import fbx
from FbxCommon import *
from DisplayMaterial import *
from DisplayCommon import *
from DisplayTexture import *



def parse(filename, jsonfile):
    global manager, scene, rootNode, segment, search, writeTree
    manager, scene = InitializeSdkObjects()
    result = LoadScene(manager, scene, filename)
    geoCount = scene.GetGeometryCount()
    print("geo count: ", geoCount)
    # unit = scene.GetGlobalSettings().GetSystemUnit().GetScaleFactorAsString()
    # print(unit)
    dic = {}
    rootNode = scene.GetRootNode()

    def segment(filename, dic):
        if rootNode is not None:
            for i in range(scene.GetGeometryCount()):
                # for i in range(1): #test
                geo = scene.GetGeometry(0)  # FbxGeometry是支持控制点变形的几何对象的基类。
                # FbxGeometry的实例可以作为 SetNodeAttribute（）的节点属性绑定到FbxNode对象。
                dic[i] = geo

                if geo is not None and geo.GetAttributeType() == FbxNodeAttribute.eMesh:
                    newScene = FbxScene.Create(manager, str(i))
                    newNode = FbxNode.Create(manager, str(i))

                    if newScene.GetGlobalSettings().GetSystemUnit() == FbxSystemUnit.cm:
                        FbxSystemUnit.m.ConvertScene(newScene)
                    newNode.SetNodeAttribute(geo)
                    newScene.GetRootNode().AddChild(newNode)

                    for j in range(newNode.GetSrcObjectCount()):
                        nodeSrc = newNode.GetSrcObject(j)
                        if not nodeSrc.IsConnectedDstObject(newScene):
                            nodeSrc.ConnectDstObject(newScene)
                        nodeSrc.DisconnectDstObject(scene)

                    # mat = geo.GetNode().GetMaterialCount()
                    # print(mat)
                    matCount = geo.GetNode().GetSrcObjectCount(FbxCriteria.ObjectType(FbxSurfaceMaterial.ClassId))
                    for m in range(matCount):
                        mat = geo.GetNode().GetSrcObject(FbxCriteria.ObjectType(FbxSurfaceMaterial.ClassId), m)
                        if not mat.IsConnectedDstObject(newScene):
                            mat.ConnectDstObject(newScene)
                            mat.ConnectDstObject(newNode)
                        mat.DisconnectDstObject(scene)
                        if mat:
                            for texIndex in range(FbxLayerElement.sTypeTextureCount()):
                                prop = mat.FindProperty(FbxLayerElement().sTextureChannelNames(texIndex))
                                if prop.IsValid():
                                    layeredTexCount = prop.GetSrcObjectCount(
                                        FbxCriteria.ObjectType(FbxLayeredTexture.ClassId))
                                    if layeredTexCount > 0:
                                        for t in range(layeredTexCount):
                                            tex = prop.GetSrcObject(FbxCriteria.ObjectType(FbxLayeredTexture.ClassId),
                                                                    t)
                                            if not tex.IsConnectedDstObject(newScene):
                                                tex.ConnectDstObject(newScene)
                                    else:
                                        texCount = prop.GetSrcObjectCount(FbxCriteria.ObjectType(FbxTexture.ClassId))
                                        for t in range(texCount):
                                            tex = prop.GetSrcObject(FbxCriteria.ObjectType(FbxTexture.ClassId), t)
                                            if not tex.IsConnectedDstObject(newScene):
                                                tex.ConnectDstObject(newScene)

                                                # SaveScene(manager, newScene, "./output3/"+ str(i) +".fbx",0)
                                                # 将模型拆分成细小模型
                                                # for e in range(scene.GetGeometryCount()+1):
                                                #     # lSampleFileName = "C:/processor/FBX/FBX Python SDK/2020.2/samples/ImportScene/output/ExportScene"+str(e)+".fbx"
                                                #     lSampleFileName = "output/ExportScene"+str(e)+".fbx"
                                                #     # Create the scene.
                                                #     lResult = SaveScene(manager, newScene, lSampleFileName)
                                                #     if lResult == False:
                                                #         print("\n\nAn error occurred while creating the scene...\n")
                                                #         manager.Destroy()
                                                # sys.exit(0)
                                                # Destroy all objects created by the FBX SDK.

    print("================write tree==================")

    def search(value):
        dic = {}
        segment(filename, dic)
        for k, v in dic.items():
            if value is v:
                # print("key:",k,"value:",v)
                return k

    tree = {}

    def writeTree(node, tree):
        childCount = node.GetChildCount()
        geo = node.GetGeometry()
        if geo is not None and geo.GetAttributeType() == FbxNodeAttribute.eMesh:
            # tree["geometry"] = keyList[valueList.index(geo)]
            tree["geometry"] = search(geo)
        else:
            tree["geometry"] = "null"

        matrix1 = node.EvaluateLocalTransform()
        trans = [matrix1.GetT()[0], matrix1.GetT()[1], matrix1.GetT()[2]]
        rot = [matrix1.GetR()[0], matrix1.GetR()[1], matrix1.GetR()[2]]
        scale = [matrix1.GetS()[0], matrix1.GetS()[1], matrix1.GetS()[2]]
        tree["translation"] = trans
        tree["rotation"] = rot
        tree["scaling"] = scale
        tree["subnode"] = {}

        if childCount == 0:
            return
        for i in range(childCount):
            childNode = node.GetChild(i)
            childName = childNode.GetName()
            if not tree.get(childName):
                tree["subnode"][childName] = {}
                writeTree(childNode, tree["subnode"][childName])
            else:
                writeTree(childNode, tree["subnode"][childName])

    writeTree(rootNode, tree)
    print("================finish==================")
    # print(tree)
    with open(jsonfile, "w", encoding="utf-8") as f:
        f.write(json.dumps(tree, ensure_ascii=False, indent=4))
    manager.Destroy()





